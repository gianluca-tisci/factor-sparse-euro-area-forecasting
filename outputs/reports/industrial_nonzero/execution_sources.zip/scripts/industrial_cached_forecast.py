"""Canonical per-target forecast mapping with saved nonzero-IQR factor checkpoints.

Only the factor-estimation block is replaced by checkpoint reconstruction.
The saved EM diagnostics are retained, not fabricated from a new likelihood trace.
All four original targets must reproduce the primary run before results are accepted.
"""

import time

import numpy as np
import pandas as pd

from src.forecasting.dfm import Fit
from src.forecasting.experiment import (
    MODELS,
    BalancedStartEM,
    MixedFrequencyEM,
    Parameters,
    balanced_pca,
    bic_regression,
    carried_common,
    clean_window,
    dictionary,
    factor_common_at,
    fit_var,
    own_features,
    pca_fit,
    radius,
    sparse_predict,
    starting_point,
    target_month,
    training_sample,
)


def run_cached_origin(
    panel,
    info,
    lags,
    origin,
    design,
    settings,
    previous=None,
    ordinal=0,
    checkpoint=None,
    source_log=None,
):
    """One shared DFM and PCA fit, then the same per-target code path for all 47."""
    previous = starting_point(settings, previous)
    selected_models = settings.get("models", MODELS)
    start_time = time.perf_counter()
    published, cleaned, z, mean, scale, outliers = clean_window(panel, lags, origin)
    monitoring = design["factor_model"]["fit_monitoring"]
    r = design["factor_model"]["selected_r"]
    nm = int((info.Frequency == "M").sum())
    initializer = settings.get("dfm_initialization", "original")
    if initializer not in ["original", "balanced_t_minus_3"]:
        raise ValueError(f"Unknown experimental DFM initializer: {initializer}")
    em_class = BalancedStartEM if initializer == "balanced_t_minus_3" else MixedFrequencyEM
    if initializer == "balanced_t_minus_3" and int(lags.iloc[:nm].max()) != 3:
        raise ValueError("The experimental initializer requires a maximum monthly delay of 3")
    model = em_class(z, nm, r, initial_variance=settings["initial_factor_variance"])
    # Saved factors depend on the panel and origin, not on the list of targets.
    assert previous is None and checkpoint is not None and source_log is not None
    with np.load(checkpoint) as archive:
        np.testing.assert_allclose(mean.to_numpy(), archive["mean"], rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(scale.to_numpy(), archive["scale"], rtol=1e-12, atol=1e-12)
        params = Parameters(
            *(archive[k].copy() for k in ["loadings", "variances", "ar", "innovation"])
        )
    fit = Fit(
        model,
        params,
        model.expectation(params),
        source_log["iterations"],
        source_log["converged"],
        [],
    )
    crashed, cold_check_gap = False, None
    rho = radius(fit.params.ar)
    flagged = (
        not fit.converged
        or rho >= monitoring["flag_rho"]
        or crashed
        or (cold_check_gap is not None and cold_check_gap > monitoring["cold_check_rho_gap"])
    )
    # Training responses may be cleaned; scoring always uses the published panel.
    policy = settings.get("training_outlier_policy", "published_labels_and_own_lags")
    if policy not in ["cleaned_inputs_and_labels", "published_labels_and_own_lags"]:
        raise ValueError(f"Unknown training outlier policy: {policy}")
    training_values = cleaned if policy == "cleaned_inputs_and_labels" else published
    common = fit.common() * scale + mean
    residual_labels = training_values - common
    residual_inputs = cleaned - common
    origins = z.index
    w_mq, _ = dictionary(residual_inputs, info.Frequency, lags, origins)
    w_m = w_mq.loc[:, w_mq.columns.str.contains("__M", regex=False)]
    w_raw, _ = dictionary(cleaned, info.Frequency, lags, origins)
    # PCR and EM retain their original PCA estimates; only the two VAR
    # benchmarks adopt the balanced-end method requested on 7 November.
    pca_iterations, var_order = None, None
    if set(selected_models) & {"PCR", "AR_PCR", "PCA_VAR", "PCA_VAR_LASSO"}:
        pcr_f, _, _ = pca_fit(z.iloc[:, :nm], r)
        f, loading, factor_index, pca_iterations = balanced_pca(
            z.iloc[:, :nm], r, int(lags.iloc[:nm].max())
        )
        var, var_order = fit_var(f, design["factor_forecast"]["max_lag"])
        pca_common = carried_common(f, loading, var, factor_index, z.index)
        pca_common.columns = z.columns[:nm]
        pca_common = pca_common * scale.iloc[:nm] + mean.iloc[:nm]
        pca_residuals = cleaned.iloc[:, :nm] - pca_common
        pca_labels = training_values.iloc[:, :nm] - pca_common
        w_pca, _ = dictionary(pca_residuals, info.Frequency, lags, origins)
        # PCR has a scalar target regression on PCA factor lags, distinct from PCA+VAR.
        # The factor reference date is at/before the latest fully released monthly row.
        # This prevents a historical target from entering its own contemporaneous PC regressor.
        f_index = pd.DataFrame(pcr_f, index=origins, columns=[f"F{k + 1}" for k in range(r)])
        factor_features = pd.DataFrame(index=origins)
        factor_delay = int(lags.iloc[:nm].max())
        for lag in range(8):
            for name in f_index:
                factor_features[f"{name}__lag{lag + 1}"] = f_index[name].shift(factor_delay + lag)
    records, selections, tuning = [], [], []
    for j, name in enumerate(z.columns[:nm]):
        if name not in settings.get("targets", z.columns[:nm]):
            continue
        target_date = target_month(origin, lags[name])
        forecasts = {}
        unavailable = {}

        def estimate(label, function, *args, unavailable=unavailable):
            try:
                result = function(*args)
            except (ValueError, RuntimeError, np.linalg.LinAlgError) as error:
                if "information_set" not in settings:
                    raise
                unavailable[label] = f"{type(error).__name__}: {error}"
                if function is sparse_predict:
                    return np.nan, pd.Series(dtype=float), {"failure_reason": unavailable[label]}
                return np.nan, {"failure_reason": unavailable[label]}
            if "failure_reason" in result[-1]:
                unavailable[label] = result[-1]["failure_reason"]
            return result

        mf_common = float(mean[name] + scale[name] * fit.common_at(target_date, name))
        pc_common = 0.0
        if set(selected_models) & {"PCA_VAR", "PCA_VAR_LASSO"}:
            pc_common = float(
                mean[name]
                + scale[name] * factor_common_at(f, loading, var, factor_index, target_date, j)
            )
        own = own_features(training_values, info, lags, origins, name)
        own_groups = [list(own.columns[:p]) for p in range(1, 5)]
        x, y = training_sample(own, training_values[name], lags[name], origin)
        if "AR" in selected_models:
            forecasts["AR"], detail = estimate(
                "AR", bic_regression, x, y, own.loc[origin], own_groups
            )
            tuning.append({"target": name, "model": "AR", **detail})
        if "RW" in selected_models:
            forecasts["RW"] = float(published[name].dropna().iloc[-1])
        for benchmark, with_ar in [("PCR", False), ("AR_PCR", True)]:
            if benchmark not in selected_models:
                continue
            features = pd.concat([factor_features, own], axis=1) if with_ar else factor_features
            groups = []
            for q in range(1, 9):
                pcs = list(factor_features.columns[: q * r])
                if with_ar:
                    groups.extend([pcs + list(own.columns[:p]) for p in range(1, 5)])
                else:
                    groups.append(pcs)
            x, y = training_sample(features, training_values[name], lags[name], origin)
            forecasts[benchmark], detail = estimate(
                benchmark, bic_regression, x, y, features.loc[origin], groups
            )
            tuning.append({"target": name, "model": benchmark, **detail})
        forecasts["MF_factor_only"] = mf_common
        forecasts["PCA_VAR"] = pc_common
        own_u = own_features(residual_labels, info, lags, origins, name)
        x, y = training_sample(own_u, residual_labels[name], lags[name], origin)
        u, detail = estimate(
            "MF_factor_own_AR", bic_regression, x, y, own_u.loc[origin], own_groups
        )
        forecasts["MF_factor_own_AR"] = mf_common + u
        tuning.append({"target": name, "model": "MF_factor_own_AR", **detail})
        for label, features, response, base in [
            ("FarmPredict_M", w_m, residual_labels[name], mf_common),
            ("FarmPredict_MQ", w_mq, residual_labels[name], mf_common),
            (
                "PCA_VAR_LASSO",
                w_pca if "PCA_VAR_LASSO" in selected_models else None,
                pca_labels[name] if "PCA_VAR_LASSO" in selected_models else None,
                pc_common,
            ),
            ("sparse_only", w_raw, training_values[name], 0.0),
        ]:
            if label not in selected_models:
                continue
            x, y = training_sample(features, response, lags[name], origin)
            prediction, selected, detail = estimate(
                label, sparse_predict, x, y, features.loc[origin]
            )
            forecasts[label] = base + prediction
            tuning.append({"target": name, "model": label, **detail})
            for term, coefficient in selected.items():
                variable, position = term.rsplit("__", 1)
                selections.append(
                    {
                        "target": name,
                        "model": label,
                        "term": term,
                        "predictor": variable,
                        "frequency": position[0],
                        "released_position": int(position[1:]),
                        "coefficient": coefficient,
                    }
                )
        actual = panel.loc[target_date, name]
        for label in selected_models:
            value = forecasts[label]
            if (
                not np.isfinite(value)
                and label not in unavailable
                and "information_set" not in settings
            ):
                raise RuntimeError(f"Nonfinite forecast: {origin} {name} {label}")
            records.append(
                {
                    "target": name,
                    "target_month": str(target_date),
                    "model": label,
                    "actual": float(actual),
                    "forecast": value,
                    "error": float(actual - value),
                    "flagged": flagged,
                    "status": "unavailable" if label in unavailable else "ok",
                    "failure_reason": unavailable.get(label, ""),
                }
            )
    log = {
        "origin": str(origin),
        "n_train_months": len(z),
        "iterations": fit.iterations,
        "converged": fit.converged,
        "llf": fit.posterior.llf,
        "rho": rho,
        "crashed": crashed,
        "cold_check_rho_gap": cold_check_gap,
        "flagged": flagged,
        "pca_iterations": pca_iterations,
        "pca_var_order": var_order,
        "input_outliers": int(outliers.sum().sum()),
        **(
            {
                "data_availability": {
                    name: {
                        "published": int(published[name].notna().sum()),
                        "cleaned": int(cleaned[name].notna().sum()),
                        "outliers": int(outliers[name].sum()),
                    }
                    for name in panel
                }
            }
            if "information_set" in settings
            else {}
        ),
        "em_min_likelihood_increment": source_log["em_min_likelihood_increment"],
        "seconds": time.perf_counter() - start_time,
    }
    for rows in [records, selections, tuning]:
        for row in rows:
            row["origin"] = str(origin)
    return records, selections, tuning, log, (fit.params, scale, mean)
