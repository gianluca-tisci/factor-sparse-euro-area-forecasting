"""Refresh ten-target robustness using the identical per-origin primary factor fits."""

import hashlib
import json
import shutil
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import pandas as pd
from threadpoolctl import threadpool_limits

from scripts import industrial_nonzero as reports
from scripts.fixed_factor_mqe_nonzero import verify_saved_files
from scripts.industrial_cached_forecast import run_cached_origin
from src.forecasting.experiment import prepare

SOURCE = Path("outputs/forecasts/paper_experiment_nonzero_iqr")
OUTPUT = Path("outputs/forecasts/industrial_nonzero_cached")


def panel_run(panel_name):
    design, settings, hashes, panel, info, lags, origins = prepare(str(reports.PROFILE), panel_name)
    primary = json.loads((SOURCE / panel_name / "metadata.json").read_text())
    newline_only = verify_saved_files(primary)
    for key, value in primary["profile"].items():
        if key not in ["targets", "classification"]:
            assert settings[key] == value, key
    assert list(panel.columns) == primary["panel_members"]
    root = OUTPUT / panel_name
    root.mkdir(parents=True)
    metadata = dict(primary)
    files = [Path(p) for p in primary["source_hashes"]]
    files += [
        Path("scripts/industrial_nonzero_cached.py"),
        Path("scripts/industrial_cached_forecast.py"),
    ]
    metadata.update(
        profile=settings,
        input_hashes=hashes,
        source_hashes={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        completion="RUNNING",
        factor_refits=0,
        execution="Reuse saved primary nonzero-IQR factor fits; recompute all ten targets",
        verified_newline_only_differences=newline_only,
    )
    (root / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    with threadpool_limits(limits=1):
        for ordinal, origin in enumerate(origins):
            checkpoint = SOURCE / panel_name / str(origin) / "parameters.npz"
            log_path = SOURCE / panel_name / str(origin) / "fit.json"
            log = json.loads(log_path.read_text())
            rows, selected, tuning, fitted, _ = run_cached_origin(
                panel,
                info,
                lags,
                origin,
                design,
                settings,
                ordinal=ordinal,
                checkpoint=checkpoint,
                source_log=log,
            )
            fitted.update(
                factor_checkpoint_reused=True,
                factor_checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
            )
            folder = root / str(origin)
            folder.mkdir()
            for name, frame in [("forecasts", rows), ("selected", selected), ("tuning", tuning)]:
                pd.DataFrame(frame).to_csv(folder / f"{name}.csv", index=False)
            (folder / "fit.json").write_text(json.dumps(fitted, indent=2), encoding="utf-8")
            shutil.copyfile(checkpoint, folder / "parameters.npz")
            print(
                f"{panel_name} [{ordinal + 1}/{len(origins)}] {origin}: cached factors", flush=True
            )
    metadata["completion"] = "COMPLETE"
    (root / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


if __name__ == "__main__":
    if OUTPUT.exists():
        raise FileExistsError("Existing industrial runs are immutable")
    with ProcessPoolExecutor(max_workers=2) as pool:
        list(pool.map(panel_run, reports.PANELS))
    reports.OUTPUT = OUTPUT
    reports.report()
